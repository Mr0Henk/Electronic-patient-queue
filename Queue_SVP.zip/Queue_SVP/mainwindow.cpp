#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "infowindow.h"
#include <QMessageBox>
#include <QApplication>
#include <QFile>
#include <QTextStream>
#include <QDesktopServices>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Электронная очередь пациентов");
    QApplication::setWindowIcon(QIcon(":/rec/img/icon.png"));
    readPatientsFromFile();
    readCodeIFromFile();
}

int MainWindow::getCodeI() const{
    return CodeI;
}

void MainWindow::setCodeI(const int newCodeI){
    CodeI = newCodeI;
    writeCodeIToFile();
}

void MainWindow::Add_Pacient(){
    QString Snils = ui->lineEdit->text();
    bool isNumber;
    qint64 snilsNumber = Snils.toFloat(&isNumber);
    if (ui->QueueWidget->count() == 0) {
        setCodeI(0);
    }
    if (isNumber && snilsNumber != 0) {
        if (Snils.length() == 11) {
            setCodeI(getCodeI() + 1);
            QString Pacient = "Код в очереди: " + QString::number(getCodeI()) + "\t" + " Снилс пациента: " + Snils;
            ui->QueueWidget->addItem(Pacient);
            ui->lineEdit->clear();
            writePatientToFile(Pacient);
            // QMessageBox::information(this, "Добро пожаловать!", "Код в очереди: " + QString::number(getCodeI()));
        } else {
            QMessageBox::warning(this, "Ай-ай!", "СНИЛС должен содержать 11 символов");
        }
    } else {
        QMessageBox::warning(this, "Ой-ой!", "Кажется, вы неправильно ввели снилс! Попробуйте ещё раз");
    }
}

void MainWindow::Exit_Program(){
    QApplication::quit();
}

void MainWindow::To_Reception() {
    if (ui->QueueWidget->selectedItems().isEmpty()) {
        delete ui->QueueWidget->takeItem(0);
    } else {
        delete ui->QueueWidget->takeItem(ui->QueueWidget->row(ui->QueueWidget->currentItem()));
    }
    updatePatientsFile();
}

void MainWindow::readPatientsFromFile(){
    QFile file("pacients.txt");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        if (file.size() == 0) {
            setCodeI(0);
            writeCodeIToFile();
        } else {
        while (!in.atEnd()) {
            QString line = in.readLine();
            ui->QueueWidget->addItem(line);
        }
        file.close();}
    }

}

void MainWindow::writePatientToFile(const QString &patientInfo){
    QFile file("pacients.txt");
    if (file.open(QIODevice::Append | QIODevice::Text)) {
        QTextStream out(&file);
         out << patientInfo << "\n";
        file.close();
    }
}

void MainWindow::updatePatientsFile(){
    QFile file("pacients.txt");
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        for (int i = 0; i < ui->QueueWidget->count(); i++) {
            out << ui->QueueWidget->item(i)->text() << "\n";
        }
        file.close();
    }
}

void MainWindow::readCodeIFromFile(){
    QFile file("CodeI.txt");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        if (!in.atEnd()) {
            QString line = in.readLine();
            bool ok;
            int codeI = line.toInt(&ok);
            if (ok) {
                setCodeI(codeI);
            }
        }
        file.close();
    }
}

void MainWindow::writeCodeIToFile(){
    QFile file("CodeI.txt");
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        out << getCodeI();
        file.close();
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_addButton_clicked()
{
    Add_Pacient();
}


void MainWindow::on_receptionButton_clicked()
{
    To_Reception();
}


void MainWindow::on_add_triggered()
{
    Add_Pacient();
}


void MainWindow::on_exit_triggered()
{
    Exit_Program();
}


void MainWindow::on_info_triggered()
{
    InfoWindow info;
    info.setModal(true);
    info.exec();
}


void MainWindow::on_reseption_triggered()
{
    To_Reception();
}

void MainWindow::on_file_triggered()
{
    QString filePath = QCoreApplication::applicationDirPath() + "/pacients.txt";
    QDesktopServices::openUrl(QUrl::fromLocalFile(filePath));
}

